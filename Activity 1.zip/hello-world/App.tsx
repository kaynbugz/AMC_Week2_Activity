import React from 'react';
import {View, Text, Image, ScrollView, TextInput} from 'react-native';

const App = () => {
  return (
    <ScrollView>
      <View
      style={{
        marginInline: 5,
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <h1>Christian Ken Bugto</h1>
      <h2>REACT JS </h2>
        <Image
          source={{
            uri: 'https://pluspng.com/img-png/react-logo-png-javascript-logo-react-js-stickers-mugs-t-shirts-and-much-more-880x1136.jpg',
          }}
          style={{width: 200, height: 250, justifyContent: 'center', marginBottom: 2,}}
        />
      <TextInput
        style={{
          height: 20,
          borderColor: 'black',
          borderWidth: 1,
          marginTop: 10,
        }}
        defaultValue=">>>>>>>><<<<<<<"
       
      />
       </View>
    </ScrollView>
  );
};

export default App;