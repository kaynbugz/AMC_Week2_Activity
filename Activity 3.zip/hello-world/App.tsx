import React, {useState} from 'react';
import {Text, StyleSheet} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInANest = () => {
  const [titleText, setTitleText] = useState("Christian Ken G. Bugto");



  const onPressTitle = () => {
    setTitleText(" BSIT - 203 [pressed]");
  };

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.container}>
        <Text style={styles.baseText}>
          <Text style={styles.titleText} onPress={onPressTitle}>
            {titleText}
            {'\n'}
            {'\n'}
          </Text>
            <Text style={styles.baseText}>
        I'm currently studying at 
        <Text style={styles.innerText}> Global Reciprocal Colleges </Text>
        <Text> my program is </Text>
        <Text style={styles.innerText}> BSIT </Text>

      </Text>
        </Text>
            <Text style={styles.baseText}>
        My programming languages are,
        <Text style={styles.innerText}> JAVA, JAVA SCRIPT, C SHARP </Text>
      </Text>


      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    fontWeight: 'bold',
  },
  baseText: {
    fontWeight: 'bold',
    fontFamily: 'Cochin',
    textAlign: 'center',
    marginTop: 10,
    color: 'green'
  },
  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'red',
  },
  innerText: {
    color: 'violet',
    fontWeight: 'bold',
  },
});

export default TextInANest;